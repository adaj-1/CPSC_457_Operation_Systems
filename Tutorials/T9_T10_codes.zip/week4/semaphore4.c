//./program_name 1000
//https://www.delftstack.com/howto/c/semaphore-example-in-c/
//binary semaphore is pretty much the same as mutex
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>

static long shared = 0;
static sem_t sem;

enum {THREADS = 4};

#define errExit(msg) do { perror(msg); exit(EXIT_FAILURE); \
                               } while (0)
/*sem_post increments the semaphore, which usually corresponds to unlocking the shared resource.
 In contrast, sem_wait decrements the semaphore and denotes the locking of the resource.
 Thus, the critical section would need to start with sem_wait and end with sem_post call.*/
static void *threadFunc(void *arg)
{
    long loops = *((long *) arg);

    for (long j = 0; j < loops; j++) {
        if (sem_wait(&sem) == -1)
            errExit("sem_wait");

        shared++;

        if (sem_post(&sem) == -1)
            errExit("sem_post");
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    pthread_t t[THREADS];
    int s;
    long nloops;

    if (argc != 2) {
        fprintf(stderr, "Usage: %s num_loops\n", argv[0]);
        exit(EXIT_FAILURE);
    }
//strtol: Parses the C-string str interpreting its content 
//as an integral number of the specified base, which is returned as a long int value.
    nloops = strtol(argv[1], NULL, 0);

    if (sem_init(&sem, 0, 1) == -1)
        errExit("sem_init");

    for (int i = 0; i < THREADS; ++i) {
        s = pthread_create(&t[i], NULL, threadFunc, &nloops);
        if (s != 0)
            errExit("pthread_create");
    }

    for (int i = 0; i < THREADS; ++i) {
        s = pthread_join(t[i], NULL);
        if (s != 0)
            errExit("pthread_join");
    }

    printf("shared = %ld\n", shared);
    exit(EXIT_SUCCESS);
}
//4 threads are supposed to run a loop n times. So the value of shared=4*n.
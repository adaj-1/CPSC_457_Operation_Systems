// Example 2: Make a bunch of threads with a thread function that takes in MULTIPLE parameters.  
#include <stdio.h>    // printf 
#include <pthread.h>  // pthreads
#include <string>     // string data type 
#include <iostream>

using namespace std;

// Input parameter structure for the thread function hello()
struct helloInput
{
    int id;
    //it's the default value for the phrase
    string phrase = "I'm a thread.";
};    // don't forget this ; !!

// A function for threads to run. Let's refer to such functions as "thread functions". 
void * hello(void * param)
{
    // cast input parameter structure back into the correct type
    struct helloInput * myParam = ((struct helloInput *) param);

    // store parameters into local variables. This can be done in-line too, but it looks very ugly.
    //try to use local values instead of refrencing 
    int id = myParam -> id;
    string phrase = myParam -> phrase;
    
    // not buffered print
   // cout << id << " says: " << phrase << endl;
 
    // buffered print
   printf("%i says: %s \n", id, phrase.c_str());

    pthread_exit(NULL);
    //return NULL;
}

int main()
{
    printf("About to create a thread pool (a bunch of threads) \n");

    int n = 5;

    // declare an array of threads
    //an array for creating 5 threads
    pthread_t threadPool[n];
    // declare an array of input parameters for each thread
    //the input varibales will be of type of a struct data type named helloInput
    helloInput inputs[n];

    // create the actual threads and their thread function inputs
    for (int i = 0; i < 5; i++)
    {
        // set up hello's input parameters
        //for the first and last threads we do not want to use the default phrase
        inputs[i].id = i;   
        if (i == 4)
            inputs[i].phrase = "I'm the last thread. Bye!";
        if (i == 0)
            inputs[i].phrase = "I'm the first thread. Hello!";

        // create the thread, pass input parameters by reference
        //& can be used because it was a refrence to a variable in main scope
        //in previous example we were using i which was the local variable.
        pthread_create(&threadPool[i], NULL, hello, & inputs[i]);
    }  

    // wait for thread to finish and join with main thread
    for (int i=0; i < n; i++)
        pthread_join(threadPool[i], NULL);

    return 0;
}

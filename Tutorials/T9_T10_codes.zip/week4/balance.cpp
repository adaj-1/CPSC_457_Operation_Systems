/*
Example 1:
Use two threads to increment and decrement ballance. Expected result of ballance is 0. 

What is the actual result when executed? Explain. 
*/

#include <iostream>
#include <thread>
#include <mutex>
using namespace std;

int ballance = 0;
mutex mylock;
void change(int n){
    mylock.lock();
    for (int i=0; i<1000000; i++){
        //mylock.lock();
        ballance += n;
        //mylock.unlock();
    }
   mylock.unlock();
}

int main(int argc, char const *argv[]) {
    thread t1(change, 1);
    thread t2(change, -1);
    t1.join();
    t2.join();
    cout<<ballance<<endl;
    return 0;
}
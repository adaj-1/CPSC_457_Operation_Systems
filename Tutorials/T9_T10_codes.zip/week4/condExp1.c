/*
Example 1: Using condition variable. 
Source: https://www.bogotobogo.com/cplusplus/multithreading_pthread.php
*/
#include <pthread.h>
#include <stdio.h>
//using namespace std;

pthread_mutex_t mutex;
pthread_cond_t cond;

int buffer[100];

int loops = 5;
int length = 0;

void *producer(void *arg) {
    int i;
    for (i = 0; i < loops; i++) {
        pthread_mutex_lock(&mutex);
        //first increase the length by one then assign i to the new length
        buffer[length++] = i;
        printf("producer length %d\n", length);
        //signal the consumers that there is something to consume and they can start consuming
        pthread_cond_signal(&cond);
        pthread_mutex_unlock(&mutex);
    }
}

void *consumer(void *arg) {
    int i;
    for (i = 0; i < loops; i++) {
        pthread_mutex_lock(&mutex);
        while(length == 0) {
            printf(" consumer waiting...\n");
            //there is nothing to consume so the consumers should wait for the producers signal
            pthread_cond_wait(&cond, &mutex);
        }
        //reduce the length first and then assign it
        int item = buffer[--length];
        printf("Consumer %d\n", item);
        pthread_mutex_unlock(&mutex);
    }
}

int main(int argc, char *argv[])
{

    pthread_mutex_init(&mutex, 0);
    pthread_cond_init(&cond, 0);

    pthread_t pThread, cThread;
    pthread_create(&pThread, 0, producer, 0);
    pthread_create(&cThread, 0, consumer, 0);
    pthread_join(pThread, NULL);
    pthread_join(cThread, NULL);

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
    return 0;
}
//run several times to see different results
// Example: sum numbers with two threads
// From: Emmanuel Onu
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUMBER_OF_THREADS 2

int input;
int oddSum;
int evenSum;

// thread function 1
void * oddSummation(void * a) {
	for (int i = 1; i <= input; i = i + 2) {
        //each thread will write on itsown global memory so no contest will happen
		oddSum = oddSum + i;
	}
	pthread_exit(0);
}

// thread function 2
void * evenSummation(void * a) {
	for (int i = 2; i <= input; i = i + 2) {
        //each thread will write on itsown global memory so no contest will happen
		evenSum = evenSum + i;
	}
	pthread_exit(0);
}

int main() {
	printf("Enter the number you wish to sum to:  ");
	scanf("%d", &input);
	
	int numThreads  = 2;
	pthread_t threads[numThreads];
	
	// create two threads
  	pthread_create(&threads[0], NULL, oddSummation, NULL);
  	pthread_create(&threads[1] , NULL, evenSummation, NULL);
	
	// join threads
	for (int i = 0; i < numThreads; i++) {
		pthread_join(threads[i], NULL);
	}
	
	printf("Sum of even numbers = %d\n", evenSum);
	printf("Sum of odd numbers = %d\n", oddSum);
	exit(0);
}

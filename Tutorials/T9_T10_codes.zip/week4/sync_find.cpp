/*
Solution
***************
Exercise: The following code uses two threads to find a digit in a range of numbers. 
Compile and check the run time. 

How can this be made more efficient?
*/
#include <iostream>
#include <thread>
#include <mutex>
#include <math.h>

using namespace std;

int flag = 1;
long range = 10000000000;
bool found;
mutex found_mutex;

void search(long first, long end, long x) {
    for (long i=first; i<=end; i++){
        //prevent 
        //for loop is the scope of the lock_gaurd
        //lock_gaurd has a destructor.  it will unlock mutex and 
        //other process can use the mutex and continue the process and no deadlock will be created.
        //type of lock is "mutex"
        lock_guard <mutex> lock(found_mutex);
        //found_mutex.lock();
        if (found) break;
        //if break will never run this unlike code
         //found_mutex.unlock();
        
        if (i==x){
           // found_mutex.lock();
            cout<<"Found it! i = " << i <<endl;
            found = true;
           // found_mutex.unlock();
            break;
        }
    }
//      found_mutex.unlock();
}

int main(int argc, char const *argv[]) {
    long x = 10000;
    found = false;

    thread t1(search, 1, ceil(range/2), x);
    thread t2(search, ceil(range/2), range, x);
    
    t1.join();
    t2.join();
    return 0;
}

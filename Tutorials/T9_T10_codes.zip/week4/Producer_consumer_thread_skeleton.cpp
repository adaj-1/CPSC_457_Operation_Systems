#include <stdlib.h> //standard stuff
#include <sys/mman.h> //mmap()
#include <stdio.h> //io
#include <unistd.h> //sleep
#include <semaphore.h> //semaphore
#include <time.h> //time
#include<pthread.h> //pthread_create(), pthread_join()

#define BUFFER_SIZE 4

int* buffer;

//This is going to act as a binary semaphore
sem_t *mutex;
//These are going to act as counting semaphores
sem_t *full;
sem_t *empty;

void *producer(void* arg);
void *consumer(void* arg);

int main()
{
    //Create shared memory
    /*       PROT_READ: Pages may be read.
             PROT_WRITE: Pages may be written.
            MAP_SHARED: Share this mapping.  Updates to the mapping are visible to
              other processes mapping the same region.
              MAP_ANONYMOUS: The mapping is not backed by any file; its contents are
              initialized to zero.
              */
              //instead of pipe we are using shared memory for inter communication
    //we have 4 slots of type integer
    buffer = (int*)mmap(NULL, BUFFER_SIZE*sizeof(int*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    //Create shared semaphores
    //we have one pointer of type mutex, full, empty
    mutex = (sem_t*)mmap(NULL, 1*sizeof(sem_t*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    full = (sem_t*)mmap(NULL, 1*sizeof(sem_t*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    empty = (sem_t*)mmap(NULL, 1*sizeof(sem_t*), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    /*int sem_init(sem_t *sem, int pshared, unsigned int value);
    sem_init() initializes the unnamed semaphore at the address
       pointed to by sem.  The value argument specifies the initial
       value for the semaphore.

       The pshared argument indicates whether this semaphore is to be
       shared between the threads of a process, or between processes.
       0 means private non zero means shared between processes.
       sem_init() returns 0 on success; on error, -1 is returned, and
       errno is set to indicate the error.*/
    //we have one mutex semaphore
    sem_init(mutex, 0, 1);
    //we have 4 empty slots in the begining 
    sem_init(empty, 0, BUFFER_SIZE);
    //we have 0 full slots in the begining 
    sem_init(full, 0, 0);
    //create threads
    pthread_t producer_id, consumer_id;

    int result = pthread_create(&producer_id, NULL, producer, NULL);
    //if thread creation is unsuccessfull
    if (result != 0)
    {
        printf("Error creating producer thread\n");
    }

    result = pthread_create(&consumer_id, NULL, consumer, NULL);
    //if thread creation is unsuccessfull
    if (result != 0)
    {
        printf("Error creating consumer thread\n");
    }

    while(1)
    {
        int takenSlots;
        /*int sem_getvalue(sem_t *restrict sem, int *restrict sval);
        sem_getvalue() places the current value of the semaphore pointed
       to sem into the integer pointed to by sval.
       sem_getvalue() returns 0 on success; on error, -1 is returned and
       errno is set to indicate the error.*/
       //takenslot will have the value of the semaphore that full is pointing to
        sem_getvalue(full, &takenSlots);
        printf("Items in the buffer %d/%d\n", takenSlots, BUFFER_SIZE);
        sleep(10);
    }

    exit(0);
}

void* producer(void* arg)
{
    while(1)
    {
        //check if there is any empty slots 
        sem_wait(empty);
        //check if another threads is using it
        sem_wait(mutex);
        
		//YOUR TASK: IMPLEMENT IN/OUT POINTERS TO ADD/TAKE FROM THE BUFFERS IN FIFO FASHION
        printf("Producer creates something\n");
        //release the semaphores
        //add the number of full semaphore
        sem_post(full);
        sem_post(mutex);

        //Sleep between 0 and 3 seconds
        /*void srand(unsigned int seed)
        seed − This is an integer value to be used as seed by the pseudo-random 
        number generator algorithm.*/
        srand(time(NULL));
        sleep(rand()% 5);
    }
}

void *consumer(void* arg)
{
    while(1)
    {
        //check if there is any full slots 
        sem_wait(full);
        //check if another threads is using it
        sem_wait(mutex);
        
		//YOUR TASK: IMPLEMENT IN/OUT POINTERS TO ADD/TAKE FROM THE BUFFERS IN FIFO FASHION
        printf("Consumer takes something\n");
         //release the semaphores
        sem_post(mutex);
        //add the number of empty semaphore
        sem_post(empty);

        //Sleep between 3 and 8 seconds
        /*void srand(unsigned int seed)
        seed − This is an integer value to be used as seed by the pseudo-random 
        number generator algorithm.*/
        srand(time(NULL));
        sleep(3 + rand()% 5);
    }
}
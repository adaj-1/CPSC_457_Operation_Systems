/*
Example using a semaphore to synchronize 15 threads. 

Source: https://austingwalters.com/multithreading-semaphores/
*/
#include <iostream>      
#include <thread>        
#include <mutex>         
#include <condition_variable>
 
std::mutex mtx;             // mutex for critical section
std::condition_variable cv; // condition variable for critical section  
bool ready = false;         // Tell threads to run
int current = 0;            // current count

/* Prints the thread id / max number of threads */
void print_num(int num, int max) {

  std::unique_lock<std::mutex> lck(mtx);
  //if the thread id is not equal to current, it has to wait wait
  while(num != current || !ready){ cv.wait(lck); }      // *** Key line that prevented a race condition *** 
 // each time current is updated by increasing by one
  current++;
  std::cout << "Thread: ";
  std::cout << num + 1 << " / " << max;
  std::cout << " current count is: ";
  std::cout << current << std::endl;
  
  /* Notify next threads to check if it is their turn */
  cv.notify_all(); 
}

/* Changes ready to true, and begins the threads printing */
void run(){
  std::unique_lock<std::mutex> lck(mtx);
  ready = true;
  cv.notify_all();
}
 
int main (){

  int threadnum = 15;
  std::thread threads[15];

  /* spawn threadnum threads */
  for (int id = 0; id < threadnum; id++)
    threads[id] = std::thread(print_num, id, threadnum);

  std::cout << "\nRunning " << threadnum;
  std::cout << " in parallel: \n" << std::endl;

  run(); // Allows threads to run

  /* Merge all threads to the main thread */
  for(int id = 0; id < threadnum; id++)
    threads[id].join();

  std::cout << "\nCompleted semaphore example!\n";
  std::cout << std::endl;

  return 0;
}
//eachtime you run the code you will see the same result
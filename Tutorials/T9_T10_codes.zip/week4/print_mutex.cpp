/*
Exercise: 
What is this code doing?

What is the expected output?

What is the actual output?

Identify critical section. 

Use mutex to fix the program. 
*/

#include <iostream>
#include <thread>
#include <mutex>
using namespace std;

mutex mylock;
void print_block(int n, char ch) {
    //this will fix random printing
    mylock.lock();
    for (int i=0; i<n; i++)
    {
        //you will still see random printing 
       //mylock.lock();
        cout<<ch;
       // mylock.unlock();
    }
    mylock.unlock();
    cout <<endl;
}

int main(int argc, char const *argv[]) {
    thread t1 (print_block, 500, '*');
    thread t2 (print_block, 500, '$');
    t1.join();
    t2.join();
    return 0;
}
// Example 2: Make a bunch of threads (a thread pool) and perform some thread function.
#include <stdio.h>
#include <pthread.h>  // pthreads
#include <cinttypes>
#include <iostream>
using namespace std;
// A function for threads to run. Let's refer to such functions as "thread functions". 
void * hello(void * id)
{
    // cast input id back into the proper type
    //int tid = (int) id;    // try using this line instead. What error do you get?
    int tid = (intptr_t) id;        // notice type is intptr_t. NOT, int.
    //cout<<"HI! I'm thread #= "<<tid<<endl;
    //make sure you use the buffered print instaed of cout
    //cout can produce scrambeled and messy results
    printf("Hi! I'm thread # = %d\n", tid);
    pthread_exit(NULL);
    //return NULL;
}

int main()
{
    printf("About to create a thread pool (a bunch of threads) \n");

    int n = 5;

    // declare an array of threads
    pthread_t threadPool[n];

    // create the actual threads and their thread function inputs
    for (int i = 0; i < 5; i++)
    {
        // create the thread and pass in the single parameter for thread function
        //input of the function is always of type pointer, so we need to cast the 
        //integer i to pointer one (intptr_t) and then cast it to (void *) as it is the type of function
        pthread_create(&threadPool[i], NULL, hello, (void *) (intptr_t) i);
    }  

    // wait for all thread to finish and join with main thread
    for (int i = 0; i < n; i++)
        pthread_join(threadPool[i], NULL);

    return 0;
}

/*
Example 1: using condition variable with mutex and unique_lock (lock guard). Use notify_all function. 
Source: http://www.cplusplus.com/reference/condition_variable/condition_variable/
*/
// condition_variable example
#include <iostream>           // std::cout
#include <thread>             // std::thread
#include <mutex>              // std::mutex, std::unique_lock
#include <condition_variable> // std::condition_variable

using namespace std;

mutex mtx;
condition_variable cv;
bool ready = false;

void print_id (int id) {
  unique_lock<mutex> lck(mtx);    // unique_lock
  while (!ready) cv.wait(lck);            // wait
  // ...
  cout << "thread " << id << '\n';
}

void go() {
  unique_lock<mutex> lck(mtx);
  ready = true;
  cv.notify_all();                      // signal: unblock all threads currently waiting for this condition
}

int main ()
{
  thread threads[10];
  // spawn 10 threads:
  for (int i=0; i<10; ++i)
    threads[i] = thread(print_id,i);

  cout << "10 threads ready to race...\n";
  go();                       // go!

  for (auto& th : threads) th.join();

  return 0;
}

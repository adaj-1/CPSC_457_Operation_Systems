/*
Exercise: The following code uses two threads to find a digit in a range of numbers. 
Compile and check the run time. 

How can this be made more efficient?

Source: Sina Keshvadi (2019)
*/
#include <iostream>
#include <thread>
#include <math.h>
#include <mutex>

using namespace std;
//try break, flags and mutex
//sometimes it might work and sometimes it will not work
int flag = 0;
long range = 10000000000;
mutex mylock;
void search(long first, long end, long x) {
    for (long i=first; i<=end; i++){
         mylock.lock();
        if (flag==1){break;}
         mylock.unlock();
        if (i==x){
            mylock.lock();
            cout<<"Found it! i = " << i <<endl;
            
            flag=1;
            //break;
            //using break here can create a problem as it can break without unlocking the mutex
            mylock.unlock();
            break;
        }
        
    }
}

int main(int argc, char const *argv[]) {
    long x = 10;
    // long x=100000000;

    thread t1(search, 1, ceil(range/2), x);
    thread t2(search, ceil(range/2), range, x);
    
    t1.join();
    t2.join();
    
    return 0;
}
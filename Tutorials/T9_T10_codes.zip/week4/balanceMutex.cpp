
/*
Example 2:
Use a mutex to protect critical section.
*/

#include <iostream>
#include <thread>
#include <mutex>

using namespace std;

mutex myMutex;
int ballance = 0;

void change(int n){
    for (int i=0; i<1000000; i++){
        myMutex.lock();
        ballance += n;
        myMutex.unlock();
    }
}

int main(int argc, char const *argv[]) {
    thread t1(change, 1);
    thread t2(change, -1);
    t1.join();
    t2.join();
    cout<<ballance<<endl;
    return 0;
}
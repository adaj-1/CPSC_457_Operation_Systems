// Example 1: Make a single thread and print it's id (or number). 
#include <stdio.h>
#include <pthread.h>  // pthreads

// A function for threads to run. Let's refer to such functions as "thread functions". 
//Void * means the data type is ambiguos, So the function can accept any data type. 
void * hello(void * param)
{
    printf("Hi! I'm thread # = %d\n", pthread_self());
    pthread_exit(NULL);
    //return NULL;
}

int main()
{
    printf("About to create a thread... \n");

    // declare a thread
    pthread_t t1;

    // create the actual thread.
    // Notice: pass in reference of t1 (&t1). 
    //hello is the function thread. thread will execute this function.
    //&t1 is used to pass by the thread.
    //Second Null means no input
    //first null should always be null
    pthread_create(&t1, NULL, hello, NULL);

    // wait for thread to finish and join with main thread
    // Notice: NOT a reference of t1. 
    // it is similar to pid. will wait for all the threads to join and then exit the main process
    pthread_join(t1, NULL);

    return 0;
}
//every time you run the code you will get an arbitrary number for the thread number
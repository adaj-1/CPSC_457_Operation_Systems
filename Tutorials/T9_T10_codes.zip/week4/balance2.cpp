/*
Example 3:
Ballance but without multithreading. 

Compare runtime of example 2 and example 3. Which is faster and why?
*/

#include <iostream>
#include <mutex>
using namespace std;
//mutex mylock;
int ballance = 0;

int main(int argc, char const *argv[]) {
    for (int i=0; i<1000000; i++)
    {
        //mylock.lock();
        ballance += +1;
        ballance += -1;
        //mylock.unlock();
    }

    cout<<ballance<<endl;
    return 0;
}
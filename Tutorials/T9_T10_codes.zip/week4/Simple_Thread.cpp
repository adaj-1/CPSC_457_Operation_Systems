// Example 1: Creating a thread using <thread>
#include <iostream>
#include <thread>
#include <unistd.h>

using namespace std;

void hello(){
    cout<<"Hi! I'm thread #" << this_thread::get_id() << endl;
}

int main(int argc, char const *argv[]){
    cout<<"About to create a thread \n";

    thread t1(hello);

    // wait for thread to finish
    t1.join();


    cout<<"Thread finished\n";
    return 0;
}
/*g++ shm_create.cpp -o shm_create -lrt
./shm_create
cd /dev/shm
you can see the shared memory object still exists
so you need to add the shm_unlink command at the end to free up the memory*/
#include<sys/mman.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<iostream>

/*
 * In this simple example, we create a new shared memory
 * file using the shm_open function and then delete it.
 */

int main(){
	// This call will create a new file named BLISS in /dev/shm 
	//O_creat will create the file if does not exist
	//O_RDWR read and write access
	int fd = shm_open("BLISS", O_RDWR | O_CREAT, 0666);
	shm_unlink("BLISS");
	return 0;
}

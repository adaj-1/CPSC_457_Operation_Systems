/* In this example we share a memory region between
 * parent and child processes using anonymous 
 * file maps
 */
#include<iostream>

#include<sys/mman.h>
#include<semaphore.h>

#include<sys/types.h>
#include<unistd.h>

int main(){
	// Anonymous file maps are non-persistent, they don't need any unlinking
	int * shared_queue = (int*) mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1 ,0);
	sem_t* consumer_lock = (sem_t*) mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	/*int sem_init(sem_t *sem, int pshared, unsigned int value);
	initializes the unnamed semaphore at the address
       pointed to by sem.  The value argument specifies the initial
       value for the semaphore.
	If pshared has the value 0, then the semaphore is shared between
       the threads of a process, and should be located at some address
       that is visible to all threads (e.g., a global variable, or a
       variable allocated dynamically on the heap).

       If pshared is nonzero, then the semaphore is shared between
       processes, and should be located in a region of shared memory*/
	   //The semaphore will be created at the address pointed by consumer_lock
	   // and it will be located in a shared memory 
	   //its initial value is 0  (It is locked) 
	sem_init(consumer_lock, 1, 0);
	// Anonymous file maps are non-persistent, they don't need any unlinking

	int pid = fork();
	if (pid == 0){
		// Wait until the produer has started producing
		sem_wait(consumer_lock);
		for(int i =0; i < 4096/sizeof(int); i ++){
			std::cout << shared_queue[i] << '\n';
		}

	}
	else if (pid > 0){
		// Open the lock as soon as you have started producing
		sem_post(consumer_lock);
		for(int i =0; i < 4096/sizeof(int); i ++){
			shared_queue[i] = i;
			std::cout << "producing "<<i << '\n';
		}
	}
	return 0;
}

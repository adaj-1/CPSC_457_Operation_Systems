/*g++ sharedmem-producer.cpp -pthread  -o sharedmem-producer -lrt
./sharedmem-producer*/
/*
 * In this example, we have a  queue 
 * with the producer adding item to it and 
 * the consumer taking items from it. The consumer
 * is implemented in sharedmem-consumer.cpp
 */
#include<sys/mman.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<iostream>

#include<unistd.h>
#include<sys/types.h>

#include<semaphore.h>

using namespace std;
int main(){
	// This call will create a new file named QUEUE in /dev/shm 
	//O_creat will create the file if does not exist
	//O_RDWR read and write access
	int shared_fd = shm_open("QUEUE", O_RDWR | O_CREAT, 0666);
	// Be careful that these number are in bytes
	//truncate the size of the file to the value shown by length
	ftruncate(shared_fd, 4096);
	//mmap() to attach the shared memory segment to the process address space.
	int * shared_queue = (int*) mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, shared_fd, 0);
	
	for(int i = 0 ; i < 4096/sizeof(int) ;i ++){
		shared_queue[i] = i;
		cout<<shared_queue[i]<<" was produced"<<endl;
	}
	
	// Without any access control, this part is going to be troublesome
	// shm_unlink("QUEUE");
	// munmap(shared_queue, 4096);

	/* Using access control and synchronization mechanism 
	 * we can make sure the buffer is not deleted before 
	 * consumption
	 */
	
	//sem_open() creates a new POSIX semaphore or opens an existing
    // semaphore.  The semaphore is identified by name.
	//0666 means read and write access
	sem_t* lock = sem_open("LOCK", O_CREAT, 0666, 0);
	sem_wait(lock);
	shm_unlink("QUEUE");
	munmap(shared_queue, 4096);
	sem_unlink("LOCK");
	
	return 0;
}
